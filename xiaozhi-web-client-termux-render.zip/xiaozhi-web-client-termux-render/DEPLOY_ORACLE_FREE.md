# 小智 Web Client：Oracle Cloud Always Free 部署

## 先確認

這個程式不是靜態網站。它會長駐啟動 Flask Web 服務（5001）和 WebSocket 代理（5002），並需要連線到小智後端的 WebSocket 位址。瀏覽器語音功能通常需要 HTTPS；正式使用時建議把網域指向 VM，並用 Caddy 或 Nginx + Let's Encrypt 提供 TLS。

Oracle Always Free 的 ARM VM 適合本專案，但 Oracle 可能因帳戶所在地區容量不足而暫時無法建立 VM，也會依官方規則回收長期閒置的 Always Free 執行個體。建立 VM 時請選 Ubuntu 22.04/24.04 ARM，至少 1 OCPU、2 GB RAM，並配置公開 IPv4。

## VM 上安裝 Docker

```bash
sudo apt update
sudo apt install -y ca-certificates curl git unzip
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"
newgrp docker
```

## 上傳並啟動

把此專案資料夾上傳到 VM，例如放在 `/opt/xiaozhi-web-client-termux`：

```bash
sudo mkdir -p /opt/xiaozhi-web-client-termux
sudo chown -R "$USER":"$USER" /opt/xiaozhi-web-client-termux
cd /opt/xiaozhi-web-client-termux
cp .env.deploy.example .env
nano .env
```

至少填妥：

```dotenv
WS_URL=ws://小智後端主機:端口/路徑
DEVICE_TOKEN=小智設備令牌
PUBLIC_HOST=你的網域或VM公開IP
ENABLE_TOKEN=true
```

然後建置：

```bash
docker compose up -d --build
docker compose logs -f
```

瀏覽器先測試：`http://你的公開IP:5001`。如果要用麥克風，請不要停在 HTTP；應使用網域配合 HTTPS，並把前端設定的本地代理位址改成 `wss://你的網域/...` 或以反向代理統一到 HTTPS 入口。直接把 5001/5002 暴露到公網只適合暫時測試。

## Oracle 網路與防火牆

在 Oracle VCN 的 Ingress Rules 放行 TCP 5001、5002（暫時測試）；Ubuntu VM 內也執行：

```bash
sudo ufw allow OpenSSH
sudo ufw allow 5001/tcp
sudo ufw allow 5002/tcp
sudo ufw enable
```

正式環境只放行 80/443，讓 Caddy/Nginx 反向代理到 5001/5002，並移除 5001/5002 的公開 Ingress 規則。不要把 `DEVICE_TOKEN` 放進公開 Git 儲存庫。

## 回復與檢查

```bash
docker compose ps
docker compose logs --tail=200 xiaozhi-web
curl -I http://127.0.0.1:5001/
```

若服務啟動失敗，優先檢查：`WS_URL` 是否為可連線的 WebSocket 位址、`DEVICE_TOKEN` 是否正確、後端是否接受 `Device-Id`/`Client-Id` 標頭，以及 5001/5002 是否已被其他服務占用。
