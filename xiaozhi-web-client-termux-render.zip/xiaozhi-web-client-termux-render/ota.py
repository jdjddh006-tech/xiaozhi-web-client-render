import json
import os
import urllib.error
import urllib.request
import uuid

from dotenv import set_key


def stable_identity(env_path):
    device_id = os.getenv("DEVICE_ID", "").strip()
    if not device_id:
        mac = uuid.getnode()
        octets = [(mac >> bits) & 0xFF for bits in range(0, 48, 8)]
        device_id = ":".join(f"{value:02x}" for value in reversed(octets))
        set_key(env_path, "DEVICE_ID", device_id)
        os.environ["DEVICE_ID"] = device_id
    client_id = os.getenv("CLIENT_ID", "").strip()
    if not client_id:
        client_id = str(uuid.uuid4())
        set_key(env_path, "CLIENT_ID", client_id)
        os.environ["CLIENT_ID"] = client_id
    return device_id, client_id


def register(env_path):
    ota_url = os.getenv("OTA_URL", "").strip()
    if not ota_url:
        return None
    if not ota_url.endswith("/"):
        ota_url += "/"
    device_id, client_id = stable_identity(env_path)
    firmware = os.getenv("FIRMWARE_VERSION", "web-client-1.0.0")
    payload = {
        "version": 2,
        "language": "zh-TW",
        "flash_size": 16777216,
        "minimum_free_heap_size": "65536",
        "mac_address": device_id,
        "uuid": client_id,
        "chip_model_name": "web",
        "application": {"name": "xiaozhi-web-client", "version": firmware,
                         "compile_time": "2026-11-23T00:00:00Z", "idf_version": "web"},
        "board": {"type": "web-client", "name": "Termux Web Client", "mac": device_id},
        "protocol": {"features": {"mcp": False, "aec": False}},
    }
    headers = {"Content-Type": "application/json", "Device-Id": device_id,
               "Client-Id": client_id, "User-Agent": f"xiaozhi-web-client/{firmware}",
               "Accept-Language": "zh-TW", "Activation-Version": "1"}
    try:
        request = urllib.request.Request(ota_url, data=json.dumps(payload).encode(),
                                          headers=headers, method="POST")
        with urllib.request.urlopen(request, timeout=15) as response:
            result = json.loads(response.read().decode("utf-8"))
        websocket = result.get("websocket", {})
        if isinstance(websocket, dict) and websocket.get("url"):
            set_key(env_path, "WS_URL", websocket["url"])
            os.environ["WS_URL"] = websocket["url"]
        activation = result.get("activation", {})
        code = activation.get("code") if isinstance(activation, dict) else None
        if code:
            set_key(env_path, "ACTIVATION_CODE", str(code))
            os.environ["ACTIVATION_CODE"] = str(code)
            print(f"六位設備驗證碼: {code}")
        print("OTA 設備註冊成功")
        return result
    except urllib.error.HTTPError as error:
        print(f"OTA 設備註冊失敗：HTTP {error.code} {error.reason}")
    except Exception as error:
        print(f"OTA 設備註冊失敗：{error}")
    return None
