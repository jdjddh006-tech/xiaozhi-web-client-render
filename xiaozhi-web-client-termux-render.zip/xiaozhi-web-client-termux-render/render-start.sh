#!/bin/sh
set -eu

PORT="${PORT:-10000}"
sed "s/__PORT__/${PORT}/g" /app/nginx.conf.template > /etc/nginx/nginx.conf

python3 /app/app.py &
APP_PID=$!

cleanup() {
    kill "$APP_PID" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

exec nginx -g 'daemon off;'
