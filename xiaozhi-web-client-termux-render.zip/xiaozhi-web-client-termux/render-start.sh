#!/bin/sh
set -eu

PORT="${PORT:-10000}"
sed "s/__PORT__/${PORT}/g" /app/nginx.conf.template > /etc/nginx/nginx.conf

python3 /app/app.py &
APP_PID=$!

# Flask 會先執行官方 OTA 註冊，可能需要數秒；
# 等待內部 Web 服務真正可用後才啟動 Nginx，避免 Render 喚醒時出現 502。
i=0
while ! python3 -c 'import urllib.request; urllib.request.urlopen("http://127.0.0.1:5001/", timeout=2)' >/dev/null 2>&1; do
    if ! kill -0 "$APP_PID" 2>/dev/null; then
        echo "Flask process exited before becoming ready" >&2
        exit 1
    fi
    i=$((i + 1))
    if [ "$i" -ge 60 ]; then
        echo "Timed out waiting for Flask on port 5001" >&2
        exit 1
    fi
    sleep 1
done

cleanup() {
    kill "$APP_PID" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

exec nginx -g 'daemon off;'
