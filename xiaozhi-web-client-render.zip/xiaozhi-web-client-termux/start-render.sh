#!/bin/sh
set -eu

export WEB_PORT=5001
export PROXY_PORT=5002
export LOCAL_PROXY_URL=ws://127.0.0.1:5002

python3 app.py &
APP_PID=$!
trap 'kill "$APP_PID" 2>/dev/null || true' TERM INT EXIT

while ! wget -q -O /dev/null http://127.0.0.1:5001/; do
  if ! kill -0 "$APP_PID" 2>/dev/null; then
    wait "$APP_PID"
    exit 1
  fi
  sleep 1
done

envsubst '${PORT}' < /app/nginx.conf.template > /etc/nginx/conf.d/default.conf
exec nginx -g 'daemon off;'
